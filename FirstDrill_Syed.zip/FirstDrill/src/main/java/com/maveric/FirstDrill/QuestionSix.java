package com.maveric.FirstDrill;

import java.util.Scanner;

public class QuestionSix {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String reverse = "";
		Scanner in = new Scanner(System.in);   
	      System.out.println("Enter a string/number to check if it is a palindrome");  
	      String s = in.nextLine();   
		 for ( int i = s.length() - 1; i >= 0; i-- ) { 
	         reverse = reverse + s.charAt(i); 
		 }
		 if (s.equals(reverse))  
	         System.out.println("Entered string is a palindrome.");  
	      else  
	         System.out.println("Entered string isn't a palindrome."); 
	}

}
