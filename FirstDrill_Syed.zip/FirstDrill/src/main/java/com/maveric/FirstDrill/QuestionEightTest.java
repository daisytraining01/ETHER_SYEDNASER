package com.maveric.FirstDrill;

public class QuestionEightTest  implements QuestionEight{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QuestionEightTest eight = new QuestionEightTest();
		eight.print();
		eight.print("naser");
	}

	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Interface method implemented");
	}
	public void print(String s) {
		// TODO Auto-generated method stub
		System.out.println("method Overloading " + s);
	}

}
