package com.maveric.FirstDrill;

public interface QuestionEight {

	void print();  

}
