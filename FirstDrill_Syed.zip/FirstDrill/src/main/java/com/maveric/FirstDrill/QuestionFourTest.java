package com.maveric.FirstDrill;

public class QuestionFourTest extends QuestionFour{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//the methods can be used without creating an instance of the class
		System.out.println(displayDetails());
	}

}
