package com.maveric.FirstDrill;

public class QuestionFive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s= "REST ASSURED";
		String s1= "REST.ASSURED";
		String s2= "REST.ASSURED";
		
		System.out.println("updated string is "+ s.replace("ST", ""));
		if(s.matches(s1)) {
			System.out.println("Strings unmatched");
		}
		if(s.matches(s2)) {
			System.out.println("Strings matched");
		}
	}

}
