package com.maveric.FirstDrill;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class QuestionSeven {

	public static void main(String[] args) {
		HashMap<String, String> map = new HashMap<String, String>();
		// HashSet<HashMap<String, String>> set = new HashSet();
		map.put("Key 1", "TestValue1");
		map.put("Key 2", "TestValue2");
		map.put("Key 3", "TestValue1");
		map.put("Key 4", "TestValue2");
		map.put("Key 5", "TestValue2");
		map.put("Key 6", "TestValue3");

		Set<String> mySet = new HashSet<String>();

		for (Iterator<Entry<String, String>> itr = map.entrySet().iterator(); itr.hasNext();) {
			Map.Entry<String, String> entrySet = (Entry<String, String>) itr.next();

			String value = entrySet.getValue();

			if (!mySet.add(value)) {
				itr.remove();
			}

		}
		System.out.println("Updated Map is" + map);
	}

}
