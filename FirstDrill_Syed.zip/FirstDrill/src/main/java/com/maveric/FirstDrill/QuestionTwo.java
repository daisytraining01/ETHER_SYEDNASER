package com.maveric.FirstDrill;

public class QuestionTwo {
	static int numberOne=0;
	static int numberTwo=1;
	static int numberThree;
	static int totalNumbers = 25;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//loop starts from 2
		for(int i=2;i<totalNumbers;++i) 
		 {    
		  numberThree=numberOne+numberTwo;    
		  System.out.print(" "+numberThree);    
		  numberOne=numberTwo;    
		  numberTwo=numberThree;    
		 }    
	}

}
