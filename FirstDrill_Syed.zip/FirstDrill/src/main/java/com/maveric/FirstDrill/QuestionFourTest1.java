package com.maveric.FirstDrill;

public class QuestionFourTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QuestionFour obj = new QuestionFour();
		obj.setName("syed");
		obj.setId(2);
		System.out.println("userName is "+ obj.getName());
		System.out.println("userName is "+ obj.getId());
	}

}
