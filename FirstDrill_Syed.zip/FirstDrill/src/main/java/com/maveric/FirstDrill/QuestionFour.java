package com.maveric.FirstDrill;

public class QuestionFour {
	private String name;
	private int id;
	
	//contructor
	public QuestionFour() {
		this.id = id;
		this.name = name;
		
	}
	public String getName() {
		return name;
	}
	public void setName(String string) {
		this.name = string;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public static boolean displayDetails() {
		
		System.out.println("This is an example of inheritance");
		return false;
		
	}
	
}
