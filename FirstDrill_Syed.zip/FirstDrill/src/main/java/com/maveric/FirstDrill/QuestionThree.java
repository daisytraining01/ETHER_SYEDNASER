package com.maveric.FirstDrill;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class QuestionThree {
	static int lineCount = 0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(System.getProperty("user.dir")+"\\file.txt"));
			String line = reader.readLine();
			while (line != null) {
				if(lineCount%2 == 0) {
					System.out.println(line);
				}
					
				lineCount++;
				
				// read next line
				line = reader.readLine();
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
