package com.maveric.FirstDrill;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class QuestionOne {
	//this is Queue implementation
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<Integer> q = new LinkedList<Integer>(); 
		Stack<Integer> stack = new Stack<Integer>();
		// Adds elements {0, 1, 2, 3, 4} to queue 
        for (int i = 0; i < 5; i++) {
            q.add(i);
        	stack.push(i);
        }
        System.out.println("queue elements are" + q);
        System.out.println("first removed element is " + q.remove());
        System.out.println("remaing elements in the queue are " + q);
        //remove an element from the queue
        System.out.println("*****************************");
        System.out.println("stack elements are" + stack);
        System.out.println("first removed element from stack is "+ stack.pop());
        System.out.println("remaing elements in the stack are " + stack);

	}

}
